-- ==============================================================================
-- BANKING DATA WAREHOUSE - ANALYTICAL QUERIES
-- ==============================================================================

-- ------------------------------------------------------------------------------
-- 01. Transaction Analytics
-- Total volume and transaction value per day, week, and month.
-- ------------------------------------------------------------------------------
SELECT
    d.year,
    d.month,
    d.week_of_year,
    d.full_date,
    COUNT(f.transaction_id) AS total_volume,
    SUM(f.amount) AS total_value
FROM fact_transaction f
JOIN dim_date d ON f.date_id = d.date_id
WHERE f.status = 'SUCCESS'
GROUP BY
    d.year, d.month, d.week_of_year, d.full_date
ORDER BY
    d.full_date;

-- ------------------------------------------------------------------------------
-- 02. Customer 360
-- Most active customers based on frequency and value, & distribution per segment
-- ------------------------------------------------------------------------------
-- Top 10 Most Active Customers
SELECT
    c.customer_id,
    c.full_name,
    c.segment,
    COUNT(f.transaction_id) AS transaction_frequency,
    SUM(f.amount) AS total_transaction_value
FROM fact_transaction f
JOIN dim_customers c ON f.customer_id = c.customer_id
WHERE f.status = 'SUCCESS'
GROUP BY
    c.customer_id, c.full_name, c.segment
ORDER BY
    total_transaction_value DESC, transaction_frequency DESC
LIMIT 10;

-- Distribution by Customer Segment
SELECT
    c.segment,
    COUNT(DISTINCT c.customer_id) AS total_customers,
    COUNT(f.transaction_id) AS total_transactions,
    SUM(f.amount) AS total_transaction_value
FROM dim_customers c
LEFT JOIN fact_transaction f ON c.customer_id = f.customer_id AND f.status = 'SUCCESS'
GROUP BY
    c.segment
ORDER BY 
    total_transaction_value DESC;

-- ------------------------------------------------------------------------------
-- 03. Branch Performance
-- Highest performing branches based on transactions and value per region
-- ------------------------------------------------------------------------------
SELECT
    b.region,
    b.branch_name,
    COUNT(f.transaction_id) AS total_transactions,
    SUM(f.amount) AS total_transaction_value
FROM fact_transaction f
JOIN dim_branches b ON f.branch_id = b.branch_id
WHERE f.status = 'SUCCESS'
GROUP BY
    b.region, b.branch_name
ORDER BY
    b.region, total_transaction_value DESC;

-- ------------------------------------------------------------------------------
-- 04. Channel Analysis
-- Most used channels and migration trends to digital
-- ------------------------------------------------------------------------------
-- Most used Channels
SELECT
    c.channel_category,
    c.channel_name,
    c.is_digital,
    COUNT(f.transaction_id) AS total_volume,
    SUM(f.amount) AS total_value
FROM fact_transaction f
JOIN dim_channels c ON f.channel_id = c.channel_id
WHERE f.status = 'SUCCESS'
GROUP BY
    c.channel_category, c.channel_name, c.is_digital
ORDER BY
    total_volume DESC;

-- Monthly Digital vs Non-Digital Trend
SELECT
    d.year,
    d.month,
    c.is_digital,
    COUNT(f.transaction_id) AS total_transactions,
    SUM(f.amount) AS total_value
FROM fact_transaction f
JOIN dim_channels c ON f.channel_id = c.channel_id
JOIN dim_date d ON f.date_id = d.date_id
WHERE f.status = 'SUCCESS'
GROUP BY
    d.year, d.month, c.is_digital
ORDER BY
    d.year, d.month, c.is_digital;

-- ------------------------------------------------------------------------------
-- 05. Product Performance
-- Account products generating highest volume and average balance
-- ------------------------------------------------------------------------------
SELECT
    a.account_type,
    a.product_name,
    COUNT(f.transaction_id) AS total_transactions,
    SUM(f.amount) AS total_transaction_value,
    AVG(f.balance_after) AS avg_balance
FROM fact_transaction f
JOIN dim_accounts a ON f.account_id = a.account_id
WHERE f.status = 'SUCCESS'
GROUP BY
    a.account_type, a.product_name
ORDER BY
    total_transaction_value DESC;

-- ------------------------------------------------------------------------------
-- 06. Risk & Fraud Detection
-- Anomalous transactions and identified frauds
-- ------------------------------------------------------------------------------
SELECT
    f.transaction_id,
    f.transaction_code,
    c.full_name,
    ch.channel_name,
    f.amount,
    f.status,
    f.is_fraud,
    f.fraud_type,
    f.fraud_score,
    f.flagged_at
FROM fact_transaction f
JOIN dim_customers c ON f.customer_id = c.customer_id
JOIN dim_channels ch ON f.channel_id = ch.channel_id
-- Filter for explicitly labeled frauds OR potentially anomalous behavior
-- (e.g. FAILED status but extremely high amount)
WHERE f.is_fraud = TRUE
   OR (f.status = 'FAILED' AND f.amount > 50000000) 
ORDER BY
    f.fraud_score DESC NULLS LAST, f.amount DESC;
